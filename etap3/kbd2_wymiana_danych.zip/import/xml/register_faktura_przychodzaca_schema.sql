DECLARE
    l_schema  CLOB;
BEGIN

l_schema := '<?xml version="1.0" encoding="UTF-8"?>
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema">
    <xs:element name="FAKTURA">
        <xs:complexType>
            <xs:sequence>
                <xs:element name="NR_FAKTURY" type="xs:string" />
                <xs:element name="DATA_WYSTAWIENIA" type="xs:date" />
                <xs:element name="SPRZEDAWCA" type="KONTRAHENT" />
                <xs:element name="NABYWCA" type="KONTRAHENT" />
                <xs:sequence>
                    <xs:element name="POZYCJE_FAKTURY">
                        <xs:complexType>
                            <xs:sequence>
                                <xs:element name="POZYCJA_FAKTURY" type="POZYCJA_FAKTURY"
                                    maxOccurs="unbounded" />
                            </xs:sequence>
                        </xs:complexType>
                    </xs:element>
                    <xs:element name="STAWKA_VAT" type="xs:positiveInteger" />
                    <xs:element name="WARTOSC_KWOTY_SLOWNIE" type="xs:string" />
                    <xs:element name="NR_KONTA">
                        <xs:simpleType>
                            <xs:restriction base="xs:string">
                                <xs:length value="26"></xs:length>
                            </xs:restriction>
                        </xs:simpleType>
                    </xs:element>
                    <xs:element name="NAZWA_BANKU" type="xs:string" />
                    <xs:element name="DATA_ZAPLATY" type="xs:date" minOccurs="0" />
                    <xs:element name="TERMIN_ZAPLATY" type="xs:date" />
                    <xs:element name="SPOSOB_ZAPLATY" type="xs:string" />
                </xs:sequence>
            </xs:sequence>
        </xs:complexType>
    </xs:element>

    <xs:complexType name="KONTRAHENT">
        <xs:sequence>
            <xs:choice>
                <xs:sequence>
                    <xs:element name="IMIE" type="xs:string" />
                    <xs:element name="NAZWISKO" type="xs:string" />
                </xs:sequence>
                <xs:sequence>
                    <xs:element name="NAZWA" type="xs:string" />
                    <xs:element name="NIP">
                        <xs:simpleType>
                            <xs:restriction base="xs:string">
                                <xs:length value="10" />
                            </xs:restriction>
                        </xs:simpleType>
                    </xs:element>
                </xs:sequence>
            </xs:choice>
            <xs:element name="ADRES" type="ADRES" />
        </xs:sequence>
    </xs:complexType>

    <xs:complexType name="ADRES">
        <xs:sequence>
            <xs:element name="MIEJSCOWOSC" type="xs:string" />
            <xs:element name="KOD_POCZTOWY">
                <xs:simpleType>
                    <xs:restriction base="xs:string">
                        <xs:pattern value="[0-9]{2}-[0-9]{3}" />
                    </xs:restriction>
                </xs:simpleType>
            </xs:element>
            <xs:element name="NAZWA_ULICY" type="xs:string" />
            <xs:element name="NR_BUDYNKU" type="xs:string" />
            <xs:element name="NR_LOKALU" type="xs:string" minOccurs="0" />
        </xs:sequence>
    </xs:complexType>

    <xs:complexType name="POZYCJA_FAKTURY">
        <xs:sequence>
            <xs:element name="NAZWA" type="xs:string" />
            <xs:element name="ILOSC" type="xs:positiveInteger" />
            <xs:element name="NAZWA_JEDNOSTKI" type="xs:string" />
            <xs:element name="DATA_WYKONANIA" type="xs:date" />
            <xs:element name="NETTO" type="KWOTA" />
            <xs:element name="VAT" type="KWOTA" />
        </xs:sequence>
    </xs:complexType>

    <xs:simpleType name="KWOTA">
        <xs:restriction base="xs:double">
            <xs:minInclusive value="0" />
        </xs:restriction>
    </xs:simpleType>
</xs:schema>';

DBMS_XMLSCHEMA.registerSchema(schemaurl       => 'faktura_przychodzaca.xsd',
                                 schemadoc       => l_schema,
                                 local           => TRUE,
                                 gentypes        => FALSE,
                                 gentables       => FALSE,
                                 enablehierarchy => DBMS_XMLSCHEMA.enable_hierarchy_none);

END;
/
EXIT