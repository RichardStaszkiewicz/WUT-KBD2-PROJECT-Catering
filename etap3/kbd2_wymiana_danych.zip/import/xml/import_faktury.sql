SET serveroutput ON
DECLARE
    xslt_sheet CLOB;
    input_text CLOB;
    input_xml XMLTYPE;
    input_validate_result NUMBER(1, 0);
    transformed_input_xml XMLTYPE;
    id_sprzedawcy NUMBER(5, 0);
    id_nabywcy NUMBER(5, 0);
    id_faktury NUMBER(7, 0);
    nr_pozycji NUMBER(3, 0) := 1;
    id_jednostki NUMBER(2, 0);
    str VARCHAR2(100);
BEGIN
    xslt_sheet := '<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">

    <xsl:template match="FAKTURA">
        <FAKTURA>
            <NR_FAKTURY><xsl:value-of select="NR_FAKTURY" /></NR_FAKTURY>
            <DATA_WYSTAWIENIA><xsl:value-of select="DATA_WYSTAWIENIA" /></DATA_WYSTAWIENIA>
            <SPRZEDAWCA>
                <xsl:if test="SPRZEDAWCA/NAZWA != ''''">
                    <NAZWA><xsl:value-of select="SPRZEDAWCA/NAZWA" /></NAZWA>
                    <NIP><xsl:value-of select="SPRZEDAWCA/NIP" /></NIP>
                </xsl:if>
                <xsl:if test="SPRZEDAWCA/IMIE != ''''">
                    <IMIE><xsl:value-of select="SPRZEDAWCA/IMIE" /></IMIE>
                    <NAZWISKO><xsl:value-of select="SPRZEDAWCA/NAZWISKO" /></NAZWISKO>
                </xsl:if>
                <ADRES>
                    <MIEJSCOWOSC><xsl:value-of select="SPRZEDAWCA/ADRES/MIEJSCOWOSC" /></MIEJSCOWOSC>
                    <KOD_POCZTOWY><xsl:value-of select="SPRZEDAWCA/ADRES/KOD_POCZTOWY" /></KOD_POCZTOWY>
                    <NAZWA_ULICY><xsl:value-of select="SPRZEDAWCA/ADRES/NAZWA_ULICY" /></NAZWA_ULICY>
                    <NR_BUDYNKU><xsl:value-of select="SPRZEDAWCA/ADRES/NR_BUDYNKU" /></NR_BUDYNKU>
                    <NR_LOKALU><xsl:value-of select="SPRZEDAWCA/ADRES/NR_LOKALU" /></NR_LOKALU>
                </ADRES>
            </SPRZEDAWCA>
            <NABYWCA>
                <xsl:if test="NABYWCA/NAZWA != ''''">
                    <NAZWA><xsl:value-of select="NABYWCA/NAZWA" /></NAZWA>
                    <NIP><xsl:value-of select="NABYWCA/NIP" /></NIP>
                </xsl:if>
                <xsl:if test="NABYWCA/IMIE != ''''">
                    <IMIE><xsl:value-of select="NABYWCA/IMIE" /></IMIE>
                    <NAZWISKO><xsl:value-of select="NABYWCA/NAZWISKO" /></NAZWISKO>
                </xsl:if>
                <ADRES>
                    <MIEJSCOWOSC><xsl:value-of select="NABYWCA/ADRES/MIEJSCOWOSC" /></MIEJSCOWOSC>
                    <KOD_POCZTOWY><xsl:value-of select="NABYWCA/ADRES/KOD_POCZTOWY" /></KOD_POCZTOWY>
                    <NAZWA_ULICY><xsl:value-of select="NABYWCA/ADRES/NAZWA_ULICY" /></NAZWA_ULICY>
                    <NR_BUDYNKU><xsl:value-of select="NABYWCA/ADRES/NR_BUDYNKU" /></NR_BUDYNKU>
                    <NR_LOKALU><xsl:value-of select="NABYWCA/ADRES/NR_LOKALU" /></NR_LOKALU>
                </ADRES>
            </NABYWCA>
            <POZYCJE_FAKTURY>
                <xsl:for-each select="POZYCJE_FAKTURY/POZYCJA_FAKTURY">
                    <POZYCJA_FAKTURY>
                        <NAZWA><xsl:value-of select="NAZWA" /></NAZWA>
                        <ILOSC><xsl:value-of select="ILOSC" /></ILOSC>
                        <NAZWA_JEDNOSTKI><xsl:value-of select="NAZWA_JEDNOSTKI" /></NAZWA_JEDNOSTKI>
                        <DATA_WYKONANIA><xsl:value-of select="DATA_WYKONANIA" /></DATA_WYKONANIA>
                        <NETTO><xsl:value-of select="NETTO" /></NETTO>
                        <VAT><xsl:value-of select="VAT" /></VAT>
                        <BRUTTO><xsl:value-of select="NETTO + VAT" /></BRUTTO>
                    </POZYCJA_FAKTURY>
                </xsl:for-each>
            </POZYCJE_FAKTURY>
            <STAWKA_VAT><xsl:value-of select="STAWKA_VAT"/></STAWKA_VAT>
            <NETTO>
                <xsl:call-template name="sumNetto">
                    <xsl:with-param name="nodeSet" select="POZYCJE_FAKTURY/POZYCJA_FAKTURY"/>
                </xsl:call-template>
            </NETTO>
            <VAT>
                <xsl:call-template name="sumVAT">
                    <xsl:with-param name="nodeSet" select="POZYCJE_FAKTURY/POZYCJA_FAKTURY"/>
                </xsl:call-template>
            </VAT>
            <BRUTTO>
                <xsl:call-template name="sumBrutto">
                    <xsl:with-param name="nodeSet" select="POZYCJE_FAKTURY/POZYCJA_FAKTURY"/>
                </xsl:call-template>
            </BRUTTO>
            <WARTOSC_KWOTY_SLOWNIE><xsl:value-of select="WARTOSC_KWOTY_SLOWNIE" /></WARTOSC_KWOTY_SLOWNIE>
            <NR_KONTA><xsl:value-of select="NR_KONTA "/></NR_KONTA>
            <NAZWA_BANKU><xsl:value-of select="NAZWA_BANKU" /></NAZWA_BANKU>
            <xsl:if test="DATA_ZAPLATY != ''''">
                <DATA_ZAPLATY><xsl:value-of select="DATA_ZAPLATY"/></DATA_ZAPLATY>
            </xsl:if>
            <TERMIN_ZAPLATY><xsl:value-of select="TERMIN_ZAPLATY"/></TERMIN_ZAPLATY>
            <SPOSOB_ZAPLATY><xsl:value-of select="SPOSOB_ZAPLATY" /></SPOSOB_ZAPLATY>
        </FAKTURA>
    </xsl:template>

    <xsl:template name="sumNetto">
        <xsl:param name="nodeSet" />
        <xsl:param name="tempSum" select="0" />
        <xsl:choose>
            <xsl:when test="not($nodeSet)">
                <xsl:value-of select="$tempSum" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:variable name="pozycja" select="$nodeSet[1]/NETTO"/>
                <xsl:call-template name="sumNetto">
                    <xsl:with-param name="nodeSet" select="$nodeSet[position()>1]"/>
                    <xsl:with-param name="tempSum" select="$tempSum + $pozycja"/>
                </xsl:call-template>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    <xsl:template name="sumVAT">
        <xsl:param name="nodeSet" />
        <xsl:param name="tempSum" select="0" />
        <xsl:choose>
            <xsl:when test="not($nodeSet)">
                <xsl:value-of select="$tempSum" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:variable name="pozycja" select="$nodeSet[1]/VAT"/>
                <xsl:call-template name="sumVAT">
                    <xsl:with-param name="nodeSet" select="$nodeSet[position()>1]"/>
                    <xsl:with-param name="tempSum" select="$tempSum + $pozycja"/>
                </xsl:call-template>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
    <xsl:template name="sumBrutto">
        <xsl:param name="nodeSet" />
        <xsl:param name="tempSum" select="0" />
        <xsl:choose>
            <xsl:when test="not($nodeSet)">
                <xsl:value-of select="$tempSum" />
            </xsl:when>
            <xsl:otherwise>
                <xsl:variable name="pozycjaNetto" select="$nodeSet[1]/NETTO"/>
                <xsl:variable name="pozycjaVAT" select="$nodeSet[1]/VAT"/>
                <xsl:call-template name="sumBrutto">
                    <xsl:with-param name="nodeSet" select="$nodeSet[position()>1]"/>
                    <xsl:with-param name="tempSum" select="$tempSum + $pozycjaNetto + $pozycjaVAT"/>
                </xsl:call-template>
            </xsl:otherwise>
        </xsl:choose>
    </xsl:template>
</xsl:stylesheet>';

    input_text := '<?xml version="1.0" encoding="UTF-8"?>
<?xml-stylesheet type="test/xsl" href="faktura_stylesheet.xsl"?>
<FAKTURA xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="faktura_przychodzaca.xsd">
    <NR_FAKTURY>2/2023</NR_FAKTURY>
    <DATA_WYSTAWIENIA>2023-05-12</DATA_WYSTAWIENIA>
    <SPRZEDAWCA>
        <NAZWA>KBD2 Katering Bazodanowy</NAZWA>
        <NIP>3873379735</NIP>
        <ADRES>
            <MIEJSCOWOSC>Warszawa</MIEJSCOWOSC>
            <KOD_POCZTOWY>01-248</KOD_POCZTOWY>
            <NAZWA_ULICY>Plac Politechniki</NAZWA_ULICY>
            <NR_BUDYNKU>1</NR_BUDYNKU>
        </ADRES>
    </SPRZEDAWCA>
    <NABYWCA>
        <IMIE>Jan</IMIE>
        <NAZWISKO>Kowalski</NAZWISKO>
        <ADRES>
            <MIEJSCOWOSC>Bytom</MIEJSCOWOSC>
            <KOD_POCZTOWY>02-252</KOD_POCZTOWY>
            <NAZWA_ULICY>Kowalskiego</NAZWA_ULICY>
            <NR_BUDYNKU>123</NR_BUDYNKU>
        </ADRES>
    </NABYWCA>
    <POZYCJE_FAKTURY>
        <POZYCJA_FAKTURY>
            <NAZWA>Pierwsza pozycja</NAZWA>
            <ILOSC>1</ILOSC>
            <NAZWA_JEDNOSTKI>sztuka</NAZWA_JEDNOSTKI>
            <DATA_WYKONANIA>2023-05-09</DATA_WYKONANIA>
            <NETTO>120</NETTO>
            <VAT>12</VAT>
        </POZYCJA_FAKTURY>
        <POZYCJA_FAKTURY>
            <NAZWA>Druga pozycja</NAZWA>
            <ILOSC>6</ILOSC>
            <NAZWA_JEDNOSTKI>sztuka</NAZWA_JEDNOSTKI>
            <DATA_WYKONANIA>2023-05-12</DATA_WYKONANIA>
            <NETTO>50</NETTO>
            <VAT>13</VAT>
        </POZYCJA_FAKTURY>
        <POZYCJA_FAKTURY>
            <NAZWA>Trzecia pozycja</NAZWA>
            <ILOSC>2</ILOSC>
            <NAZWA_JEDNOSTKI>litr</NAZWA_JEDNOSTKI>
            <DATA_WYKONANIA>2023-05-09</DATA_WYKONANIA>
            <NETTO>340</NETTO>
            <VAT>50</VAT>
        </POZYCJA_FAKTURY>
        <POZYCJA_FAKTURY>
            <NAZWA>Czwarta pozycja</NAZWA>
            <ILOSC>5</ILOSC>
            <NAZWA_JEDNOSTKI>kilogram</NAZWA_JEDNOSTKI>
            <DATA_WYKONANIA>2023-05-09</DATA_WYKONANIA>
            <NETTO>100</NETTO>
            <VAT>10</VAT>
        </POZYCJA_FAKTURY>
    </POZYCJE_FAKTURY>
    <STAWKA_VAT>10</STAWKA_VAT>
    <WARTOSC_KWOTY_SLOWNIE>szescset dziesiec zlotych polskich</WARTOSC_KWOTY_SLOWNIE>
    <NR_KONTA>26374746378927337282938383</NR_KONTA>
    <NAZWA_BANKU>Bank Pocztowy</NAZWA_BANKU>
    <TERMIN_ZAPLATY>2022-03-12</TERMIN_ZAPLATY>
    <SPOSOB_ZAPLATY>0</SPOSOB_ZAPLATY>
</FAKTURA>';

    SELECT XMLTYPE.createXML(input_text, 'faktura_przychodzaca.xsd') INTO input_xml FROM dual;
    input_xml.schemaValidate;
    DBMS_OUTPUT.PUT_LINE('Wejsciowy dokument XML poprawny');


    SELECT XMLTYPE.createXML(input_xml.transform(XMLTYPE.createXML(xslt_sheet)).getClobVal(), 'faktura.xsd') INTO transformed_input_xml FROM dual;
    transformed_input_xml.schemaValidate;

    SELECT NVL((SELECT id_kontrahenta
    FROM kontrahenci
    WHERE nip=extractValue(transformed_input_xml, 'FAKTURA/SPRZEDAWCA/NIP')), NULL) INTO id_sprzedawcy FROM dual;
    IF id_sprzedawcy IS NULL THEN
        SELECT NVL((SELECT id_kontrahenta
        FROM kontrahenci
        WHERE imie=extractValue(transformed_input_xml, 'FAKTURA/SPRZEDAWCA/IMIE') AND nazwisko=extractValue(transformed_input_xml, 'FAKTURA/SPRZEDAWCA/NAZWISKO')), NULL) INTO id_sprzedawcy FROM dual;
        IF id_sprzedawcy IS NULL THEN
            raise_application_error(-20998, 'Nie znaleziono sprzedawcy w bazie. Najpierw nalezy dodac kontrahenta');
        END IF;
    END IF;

    SELECT NVL((SELECT id_kontrahenta
    FROM kontrahenci
    WHERE nip=extractValue(transformed_input_xml, 'FAKTURA/NABYWCA/NIP')), NULL) INTO id_nabywcy FROM dual;
    IF id_nabywcy IS NULL THEN
        SELECT NVL((SELECT id_kontrahenta
        FROM kontrahenci
        WHERE imie=extractValue(transformed_input_xml, 'FAKTURA/NABYWCA/IMIE') AND nazwisko=extractValue(transformed_input_xml, 'FAKTURA/NABYWCA/NAZWISKO')), NULL) INTO id_nabywcy FROM dual;
        IF id_nabywcy IS NULL THEN
            raise_application_error(-20998, 'Nie znaleziono nabywcy w bazie. Najpierw nalezy dodac kontrahenta');
        END IF;
    END IF;

    INSERT INTO faktury (NR_FAKTURY,
                         ID_NABYWCY,
                         ID_SPRZEDAWCY,
                         DATA_WYSTAWIENIA,
                         DATA_ZAPLATY,
                         TERMIN_ZAPLATY,
                         STAWKA_VAT,
                         SPOSOB_ZAPLATY,
                         NETTO,
                         VAT,
                         BRUTTO,
                         WARTOSC_KWOTY_SLOWNIE)
                VALUES (extractValue(transformed_input_xml, 'FAKTURA/NR_FAKTURY'),
                        id_nabywcy,
                        id_sprzedawcy,
                        extractValue(transformed_input_xml, 'FAKTURA/DATA_WYSTAWIENIA'),
                        NVL(extractValue(transformed_input_xml, 'FAKTURA/DATA_ZAPLATY'), NULL),
                        extractValue(transformed_input_xml, 'FAKTURA/TERMIN_ZAPLATY'),
                        extractValue(transformed_input_xml, 'FAKTURA/STAWKA_VAT'),
                        extractValue(transformed_input_xml, 'FAKTURA/SPOSOB_ZAPLATY'),
                        extractValue(transformed_input_xml, 'FAKTURA/NETTO'),
                        extractValue(transformed_input_xml, 'FAKTURA/VAT'),
                        extractValue(transformed_input_xml, 'FAKTURA/BRUTTO'),
                        extractValue(transformed_input_xml, 'FAKTURA/WARTOSC_KWOTY_SLOWNIE')) RETURNING id_faktury INTO id_faktury;

    WHILE transformed_input_xml.existsNode('FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']') = 1 LOOP
        SELECT NVL((SELECT id_jednostki FROM jednostki WHERE nazwa=extractValue(transformed_input_xml, 'FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']/NAZWA_JEDNOSTKI')), NULL) INTO id_jednostki FROM dual;
        IF id_jednostki = NULL THEN
            raise_application_error(-20997, 'Nie znaleziono jednostki. Dodaj najpierw odpowiednie w bazie.');
        END IF;
        INSERT INTO POZYCJE_FAKTUR (ID_FAKTURY,
                                    NR_POZYCJI,
                                    NAZWA,
                                    ILOSC,
                                    ID_JEDNOSTKI,
                                    DATA_WYKONANIA,
                                    NETTO,
                                    VAT,
                                    BRUTTO)
                            VALUES (id_faktury,
                                    nr_pozycji,
                                    extractValue(transformed_input_xml, 'FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']/NAZWA'),
                                    extractValue(transformed_input_xml, 'FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']/ILOSC'),
                                    id_jednostki,
                                    extractValue(transformed_input_xml, 'FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']/DATA_WYKONANIA'),
                                    extractValue(transformed_input_xml, 'FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']/NETTO'),
                                    extractValue(transformed_input_xml, 'FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']/VAT'),
                                    extractValue(transformed_input_xml, 'FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']/BRUTTO'));
        nr_pozycji := nr_pozycji + 1;
    END LOOP;


END;
/
EXIT;