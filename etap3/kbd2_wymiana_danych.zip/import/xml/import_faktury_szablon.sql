SET serveroutput ON
DECLARE
    xslt_sheet CLOB;
    input_text CLOB;
    input_xml XMLTYPE;
    input_validate_result NUMBER(1, 0);
    transformed_input_xml XMLTYPE;
    id_sprzedawcy NUMBER(5, 0);
    id_nabywcy NUMBER(5, 0);
    id_faktury NUMBER(7, 0);
    nr_pozycji NUMBER(3, 0) := 1;
    id_jednostki NUMBER(2, 0);
    str VARCHAR2(100);
BEGIN
    xslt_sheet := '<PLIK_TRANSFORMACJI>';

    input_text := '<PLIK_FAKTURY>';

    SELECT XMLTYPE.createXML(input_text, 'faktura_przychodzaca.xsd') INTO input_xml FROM dual;
    input_xml.schemaValidate;
    DBMS_OUTPUT.PUT_LINE('Wejsciowy dokument XML poprawny');


    SELECT XMLTYPE.createXML(input_xml.transform(XMLTYPE.createXML(xslt_sheet)).getClobVal(), 'faktura.xsd') INTO transformed_input_xml FROM dual;
    transformed_input_xml.schemaValidate;

    SELECT NVL((SELECT id_kontrahenta
    FROM kontrahenci
    WHERE nip=extractValue(transformed_input_xml, 'FAKTURA/SPRZEDAWCA/NIP')), NULL) INTO id_sprzedawcy FROM dual;
    IF id_sprzedawcy IS NULL THEN
        SELECT NVL((SELECT id_kontrahenta
        FROM kontrahenci
        WHERE imie=extractValue(transformed_input_xml, 'FAKTURA/SPRZEDAWCA/IMIE') AND nazwisko=extractValue(transformed_input_xml, 'FAKTURA/SPRZEDAWCA/NAZWISKO')), NULL) INTO id_sprzedawcy FROM dual;
        IF id_sprzedawcy IS NULL THEN
            raise_application_error(-20998, 'Nie znaleziono sprzedawcy w bazie. Najpierw nalezy dodac kontrahenta');
        END IF;
    END IF;

    SELECT NVL((SELECT id_kontrahenta
    FROM kontrahenci
    WHERE nip=extractValue(transformed_input_xml, 'FAKTURA/NABYWCA/NIP')), NULL) INTO id_nabywcy FROM dual;
    IF id_nabywcy IS NULL THEN
        SELECT NVL((SELECT id_kontrahenta
        FROM kontrahenci
        WHERE imie=extractValue(transformed_input_xml, 'FAKTURA/NABYWCA/IMIE') AND nazwisko=extractValue(transformed_input_xml, 'FAKTURA/NABYWCA/NAZWISKO')), NULL) INTO id_nabywcy FROM dual;
        IF id_nabywcy IS NULL THEN
            raise_application_error(-20998, 'Nie znaleziono nabywcy w bazie. Najpierw nalezy dodac kontrahenta');
        END IF;
    END IF;

    INSERT INTO faktury (NR_FAKTURY,
                         ID_NABYWCY,
                         ID_SPRZEDAWCY,
                         DATA_WYSTAWIENIA,
                         DATA_ZAPLATY,
                         TERMIN_ZAPLATY,
                         STAWKA_VAT,
                         SPOSOB_ZAPLATY,
                         NETTO,
                         VAT,
                         BRUTTO,
                         WARTOSC_KWOTY_SLOWNIE)
                VALUES (extractValue(transformed_input_xml, 'FAKTURA/NR_FAKTURY'),
                        id_nabywcy,
                        id_sprzedawcy,
                        extractValue(transformed_input_xml, 'FAKTURA/DATA_WYSTAWIENIA'),
                        NVL(extractValue(transformed_input_xml, 'FAKTURA/DATA_ZAPLATY'), NULL),
                        extractValue(transformed_input_xml, 'FAKTURA/TERMIN_ZAPLATY'),
                        extractValue(transformed_input_xml, 'FAKTURA/STAWKA_VAT'),
                        extractValue(transformed_input_xml, 'FAKTURA/SPOSOB_ZAPLATY'),
                        extractValue(transformed_input_xml, 'FAKTURA/NETTO'),
                        extractValue(transformed_input_xml, 'FAKTURA/VAT'),
                        extractValue(transformed_input_xml, 'FAKTURA/BRUTTO'),
                        extractValue(transformed_input_xml, 'FAKTURA/WARTOSC_KWOTY_SLOWNIE')) RETURNING id_faktury INTO id_faktury;

    WHILE transformed_input_xml.existsNode('FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']') = 1 LOOP
        SELECT NVL((SELECT id_jednostki FROM jednostki WHERE nazwa=extractValue(transformed_input_xml, 'FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']/NAZWA_JEDNOSTKI')), NULL) INTO id_jednostki FROM dual;
        IF id_jednostki = NULL THEN
            raise_application_error(-20997, 'Nie znaleziono jednostki. Dodaj najpierw odpowiednie w bazie.');
        END IF;
        INSERT INTO POZYCJE_FAKTUR (ID_FAKTURY,
                                    NR_POZYCJI,
                                    NAZWA,
                                    ILOSC,
                                    ID_JEDNOSTKI,
                                    DATA_WYKONANIA,
                                    NETTO,
                                    VAT,
                                    BRUTTO)
                            VALUES (id_faktury,
                                    nr_pozycji,
                                    extractValue(transformed_input_xml, 'FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']/NAZWA'),
                                    extractValue(transformed_input_xml, 'FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']/ILOSC'),
                                    id_jednostki,
                                    extractValue(transformed_input_xml, 'FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']/DATA_WYKONANIA'),
                                    extractValue(transformed_input_xml, 'FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']/NETTO'),
                                    extractValue(transformed_input_xml, 'FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']/VAT'),
                                    extractValue(transformed_input_xml, 'FAKTURA/POZYCJE_FAKTURY/POZYCJA_FAKTURY[' || nr_pozycji || ']/BRUTTO'));
        nr_pozycji := nr_pozycji + 1;
    END LOOP;


END;
/
EXIT;