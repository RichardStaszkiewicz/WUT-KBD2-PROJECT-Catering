set pagesize 0
SET LINESIZE 30000 LONG 30000 LONGCHUNKSIZE 30000
SET Trimspool on
ALTER SESSION SET NLS_NUMERIC_CHARACTERS = '. ';
SET serveroutput ON
SET TERMOUT OFF
SET FEEDBACK OFF
SPOOL export_faktury.xml;
DECLARE
    sprzedawca kontrahenci%ROWTYPE;
    nabywca kontrahenci%ROWTYPE;
    sprzedawca_xml XMLTYPE;
    nabywca_xml XMLTYPE;
    c_id_faktury NUMBER(6, 0) := 2;
    faktura_xml XMLTYPE;
    xml_valid NUMBER(1, 0);
BEGIN

    SELECT k.ID_KONTRAHENTA, k.IMIE, k.NAZWISKO, k.NAZWA, k.NIP, k.MAIL, k.TELEFON, k.ID_BANKU, k.NR_KONTA, k.CZY_FIRMA, k.MIEJSCOWOSC, k.KOD_POCZTOWY, k.NAZWA_ULICY, k.NR_BUDYNKU, k.NR_LOKALU INTO sprzedawca FROM kontrahenci k JOIN faktury f on f.ID_SPRZEDAWCY=k.ID_KONTRAHENTA WHERE f.ID_FAKTURY=c_id_faktury;
    SELECT k.ID_KONTRAHENTA, k.IMIE, k.NAZWISKO, k.NAZWA, k.NIP, k.MAIL, k.TELEFON, k.ID_BANKU, k.NR_KONTA, k.CZY_FIRMA, k.MIEJSCOWOSC, k.KOD_POCZTOWY, k.NAZWA_ULICY, k.NR_BUDYNKU, k.NR_LOKALU INTO nabywca FROM kontrahenci k JOIN faktury f on f.ID_NABYWCY=k.ID_KONTRAHENTA WHERE f.ID_FAKTURY=c_id_faktury;

    IF sprzedawca.czy_firma = 0 THEN
        SELECT XMLELEMENT("SPRZEDAWCA",
            XMLELEMENT("IMIE", sprzedawca.imie),
            XMLELEMENT("NAZWISKO", sprzedawca.nazwisko),
            XMLELEMENT("ADRES",
                XMLELEMENT("MIEJSCOWOSC", sprzedawca.miejscowosc),
                XMLELEMENT("KOD_POCZTOWY", sprzedawca.kod_pocztowy),
                XMLELEMENT("NAZWA_ULICY", sprzedawca.nazwa_ulicy),
                XMLELEMENT("NR_BUDYNKU", sprzedawca.nr_budynku),
                XMLELEMENT("NR_LOKALU", NVL(sprzedawca.nr_lokalu, ''))
            )
        )
        INTO sprzedawca_xml FROM DUAL;
    ELSE
        SELECT XMLELEMENT("SPRZEDAWCA",
            XMLELEMENT("NAZWA", sprzedawca.nazwa),
            XMLELEMENT("NIP", sprzedawca.nip),
            XMLELEMENT("ADRES",
                XMLELEMENT("MIEJSCOWOSC", sprzedawca.miejscowosc),
                XMLELEMENT("KOD_POCZTOWY", sprzedawca.kod_pocztowy),
                XMLELEMENT("NAZWA_ULICY", sprzedawca.nazwa_ulicy),
                XMLELEMENT("NR_BUDYNKU", sprzedawca.nr_budynku),
                XMLELEMENT("NR_LOKALU", NVL(sprzedawca.nr_lokalu, ''))
            )
        )
        INTO sprzedawca_xml FROM DUAL;
    END IF;

    IF nabywca.czy_firma = 0 THEN
        SELECT XMLELEMENT("NABYWCA",
            XMLELEMENT("IMIE", nabywca.imie),
            XMLELEMENT("NAZWISKO", nabywca.nazwisko),
            XMLELEMENT("ADRES",
                XMLELEMENT("MIEJSCOWOSC", nabywca.miejscowosc),
                XMLELEMENT("KOD_POCZTOWY", nabywca.kod_pocztowy),
                XMLELEMENT("NAZWA_ULICY", nabywca.nazwa_ulicy),
                XMLELEMENT("NR_BUDYNKU", nabywca.nr_budynku),
                XMLELEMENT("NR_LOKALU", NVL(nabywca.nr_lokalu, ''))
            )
        )
        INTO nabywca_xml FROM DUAL;
    ELSE
        SELECT XMLELEMENT("NABYWCA",
            XMLELEMENT("NAZWA", nabywca.nazwa),
            XMLELEMENT("NIP", nabywca.nip),
            XMLELEMENT("ADRES",
                XMLELEMENT("MIEJSCOWOSC", nabywca.miejscowosc),
                XMLELEMENT("KOD_POCZTOWY", nabywca.kod_pocztowy),
                XMLELEMENT("NAZWA_ULICY", nabywca.nazwa_ulicy),
                XMLELEMENT("NR_BUDYNKU", nabywca.nr_budynku),
                XMLELEMENT("NR_LOKALU", NVL(nabywca.nr_lokalu, ''))
            )
        )
        INTO nabywca_xml FROM DUAL;
    END IF;

    SELECT XMLELEMENT("FAKTURA",
        XMLELEMENT("NR_FAKTURY", f.NR_FAKTURY),
        XMLELEMENT("DATA_WYSTAWIENIA", f.DATA_WYSTAWIENIA),
        sprzedawca_xml,
        nabywca_xml,
        XMLELEMENT("POZYCJE_FAKTURY",
            (SELECT XMLAGG(
                XMLELEMENT("POZYCJA_FAKTURY",
                    XMLELEMENT("NAZWA", pf.nazwa),
                    XMLELEMENT("ILOSC", pf.ilosc),
                    XMLELEMENT("NAZWA_JEDNOSTKI", pf.nazwa),
                    XMLELEMENT("DATA_WYKONANIA", pf.data_wykonania),
                    XMLELEMENT("NETTO", pf.netto),
                    XMLELEMENT("VAT", pf.vat),
                    XMLELEMENT("BRUTTO", pf.brutto)
                )
            ) FROM pozycje_faktur pf
              JOIN jednostki j ON j.ID_JEDNOSTKI=pf.ID_JEDNOSTKI
              WHERE pf.ID_FAKTURY=F.ID_FAKTURY
            )
        ),
        XMLELEMENT("STAWKA_VAT", f.stawka_vat),
        XMLELEMENT("NETTO", f.netto),
        XMLELEMENT("VAT", f.vat),
        XMLELEMENT("BRUTTO", f.brutto),
        XMLELEMENT("WARTOSC_KWOTY_SLOWNIE", f.wartosc_kwoty_slownie),
        XMLELEMENT("NR_KONTA", k.nr_konta),
        XMLELEMENT("NAZWA_BANKU", b.nazwa),
        XMLELEMENT("DATA_ZAPLATY", f.data_zaplaty),
        XMLELEMENT("TERMIN_ZAPLATY", f.termin_zaplaty),
        XMLELEMENT("SPOSOB_ZAPLATY", f.sposob_zaplaty)
    ) INTO faktura_xml FROM faktury f
      JOIN kontrahenci k ON k.id_kontrahenta=f.id_sprzedawcy
      JOIN banki b ON b.id_banku=k.id_banku
      WHERE f.id_faktury=c_id_faktury;

    DBMS_OUTPUT.put_line(faktura_xml.getClobVal());
    SELECT XMLISVALID(faktura_xml, 'faktura.xsd') INTO xml_valid FROM dual;
    IF xml_valid = 1 THEN
        DBMS_OUTPUT.put_line('<!--Schemat zweryfikowany pomyslnie-->');
    ELSE
        DBMS_OUTPUT.put_line('<!--Schemat zweryfikowany jako bledny-->');
    END IF;
END;
/
SPOOL OFF
EXIT;
